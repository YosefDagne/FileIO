import java.util.ArrayList;

public class Salad {
    //Attributes - variables that describe a salad
    String greens;
    String protein;
    ArrayList<String> toppings;
    boolean isVegan;

    //Constructor
    public Salad() {
    }//end constructor

    //Accessor methods - getters and setters
    public String getGreens() {
        return greens;
    }

    public void setGreens(String greens) {
        this.greens = greens;
    }

    public String getProtein() {
        return protein;
    }

    public void setProtein(String protein) {
        this.protein = protein;
    }

    public ArrayList<String> getToppings() {
        return toppings;
    }

    public void setToppings(ArrayList<String> toppings) {
        this.toppings = toppings;
    }

    public boolean isVegan() {
        return isVegan;
    }

    public void setVegan(boolean vegan) {
        isVegan = vegan;
    }
}//end class
